<?php

Route::resource('areaacademica', 'PlanCurricular\AreaAcademicaController',['names'=>'admin.areaacademica']);


