<?php

Route::resource('asignatura-grado-seccion', 'PlanCurricular\AsignaturaGradoSeccionController',['names'=>'admin.ags']);


