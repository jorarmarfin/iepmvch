<?php

Route::resource('productos', 'ProductoController',['names'=>'admin.productos']);


