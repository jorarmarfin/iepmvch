<?php

Route::resource('users', 'UsersController',['names'=>'admin.users']);


