<?php

Route::get('/','HomeController@index')->name('home.index');
/*Route::get('administrador','HomeController@administrador')->name('administrador.index');
Route::get('psicologo','HomeController@psicologo')->name('psicologo.index');
*/

