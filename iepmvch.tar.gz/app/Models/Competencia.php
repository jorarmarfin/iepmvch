<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Competencia extends Model
{
    protected $table = 'competencia';
    protected $fillable = ['idnivel', 'ciclo', 'nombre','orden','activo','idarea','indicadores'];
}
