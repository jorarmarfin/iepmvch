<script src=<?php echo e(asset("assets/global/plugins/jquery.min.js")); ?> type="text/javascript"></script>
<script src=<?php echo e(asset("assets/global/plugins/bootstrap/js/bootstrap.min.js")); ?> type="text/javascript"></script>
<script src=<?php echo e(asset("assets/global/plugins/js.cookie.min.js")); ?> type="text/javascript"></script>
<script src=<?php echo e(asset("assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js")); ?> type="text/javascript"></script>
<script src=<?php echo e(asset("assets/global/plugins/jquery.blockui.min.js")); ?> type="text/javascript"></script>
<script src=<?php echo e(asset("assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js")); ?> type="text/javascript"></script>
