<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
    <?php echo Alert::render(); ?>


        <!-- BEGIN Portlet PORTLET-->
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-table"></i>
                    Lista de Personal
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                    <a href="" class="fullscreen"> </a>
                    <a href="javascript:;" class="remove"> </a>
                </div>
            </div>
            <div class="portlet-body">
            <?php echo Form::boton('Nuevo Personal',route('admin.personal.create'),'green','fa fa-plus'); ?>

            <?php echo Form::boton('Disponibilidad',route('admin.disponibilidad.index'),'green-meadow','fa fa-calendar'); ?>

            <?php echo Form::boton('Personal Inactivo',route('admin.personal.inactivo'),'red','fa fa-minus'); ?>

            <p></p>
                <table class="table table-striped table-hover" id="PersonalData">
                    <thead>
                        <tr>
                            <th> Paterno </th>
                            <th> Materno </th>
                            <th> Nombres </th>
                            <th> Foto </th>
                            <th> Estado </th>
                            <th> Opciones </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $Lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td> <?php echo e($item->paterno); ?> </td>
                            <td> <?php echo e($item->materno); ?> </td>
                            <td> <?php echo e($item->nombres); ?> </td>
                            <td><a href="<?php echo e(route('admin.personal.show',$item->id)); ?>"><img src="<?php echo e(asset('/storage/'.$item->foto)); ?>"  width='25px'> </a></td>
                            <td> <?php echo LinkActivo($item->activo,route('admin.personal.activo',$item->id)); ?>  </td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-xs green-dark dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"> Opciones
                                        <i class="fa fa-angle-down"></i>
                                    </button>
                                    <ul class="dropdown-menu pull-left" role="menu">
                                        <li>
                                            <a href="<?php echo e(route('admin.personal.show',$item->id)); ?>">
                                                <i class="fa fa-eye"></i> Show </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin.personal.edit',$item->id)); ?>">
                                                <i class="fa fa-edit"></i> Edit </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin.personal.delete',$item->id)); ?>">
                                                <i class="fa fa-trash"></i> Delete </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin.personal.delete',$item->id)); ?>">
                                                <i class="fa fa-trash"></i> Crea Usuario </a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-scripts'); ?>
<script>
$('#PersonalData').dataTable({
    "language": {
        "emptyTable": "No hay datos disponibles",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ filas",
        "search": "Buscar Personal :",
        "lengthMenu": "_MENU_ registros"
    },
    "bProcessing": true,
    "pagingType": "bootstrap_full_number",
    "order": [1,"asc"]
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-styles'); ?>
<?php echo Html::style('assets/global/plugins/datatables/datatables.min.css'); ?>

<?php echo Html::style('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-js'); ?>
<?php echo Html::script('assets/global/plugins/jquery-ui/jquery-ui.min.js'); ?>

<?php echo Html::script('assets/global/scripts/datatable.js'); ?>

<?php echo Html::script('assets/global/plugins/datatables/datatables.min.js'); ?>

<?php echo Html::script('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Modulo de personal
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>