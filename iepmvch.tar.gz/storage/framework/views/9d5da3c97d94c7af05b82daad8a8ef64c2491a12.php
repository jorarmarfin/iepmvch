<?php $__env->startSection('content'); ?>
<?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
    <div class="col-md-12">
        <?php echo Alert::render(); ?>

        <!-- BEGIN Portlet PORTLET-->
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-table"></i>
                    Listado de matriculas realizadas
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                    <a href="" class="fullscreen"> </a>
                    <a href="javascript:;" class="remove"> </a>
                </div>
            </div>
            <div class="portlet-body">
             <?php echo Form::open(['route'=>'admin.matricula.store','method'=>'POST']); ?>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <?php echo Form::label('lblAlumno', 'Escoger el alumno a matricular', ['class'=>'control-label']); ?>

                                <?php echo Form::select('idalumno', [], null , ['class'=>'form-control','id'=>'matriculables']); ?>

                            </div>
                        </div><!--/span-->
                    </div><!--/row-->
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <?php echo Form::label('lblGrado', 'Escoger el grado al que fue promovido', ['class'=>'control-label']); ?>

                                <?php echo Form::select('idgradoseccion', $gradoseccion, null , ['class'=>'form-control']); ?>

                            </div>
                        </div><!--/span-->
                        <div class="col-md-4">
                            <div class="form-group">
                                <?php echo Form::label('lblTipo', 'Tipo de Matricula', ['class'=>'control-label']); ?>

                                <?php echo Form::select('idtipo', $tipomatricula, EstadoId('TIPO MATRICULA','Activa') , ['class'=>'form-control']); ?>

                            </div>
                        </div><!--/span-->
                        <div class="col-md-4">
                            <div class="form-group">
                                <p></p>
                            <?php echo Form::enviar('Matricular'); ?>

                            </div>
                        </div><!--/span-->
                    </div><!--/row-->
                <?php echo Form::close(); ?>

                <?php echo Form::boton('Reporte Matricula',route('admin.matricula.reporte'),'green-meadow','fa fa-file-pdf-o'); ?>

                <h3 >Alumnos matriculados</h3>
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-striped table-hover" id="Matriculados">
                            <thead>
                                <tr>
                                    <th> Alumnos </th>
                                    <th> Nivel Matriculado</th>
                                    <th> Grado Matriculado</th>
                                    <th> Foto </th>
                                    <th> Periodo </th>
                                    <th> Tipo </th>
                                    <th> Opciones </th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>  </th>
                                    <th>  </th>
                                    <th>  </th>
                                    <th>  </th>
                                    <th>  </th>
                                    <th>  </th>
                                    <th>  </th>
                                </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $Lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td> <?php echo e($item->paterno.' - '.$item->materno.', '.$item->nombres); ?> </td>
                                    <td> <?php echo e($item->nivel); ?> </td>
                                    <td> <?php echo e($item->grado); ?> </td>
                                    <td><a href="<?php echo e(route('admin.alumnos.show',$item->idalumno)); ?>"><img src="<?php echo e(asset('/storage/'.$item->foto)); ?>"  width='25px'> </a></td>
                                    <td> <?php echo e($item->year); ?> </td>
                                    <td> <?php echo e($item->tipo); ?> </td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-xs green-dark dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"> Opciones
                                                <i class="fa fa-angle-down"></i>
                                            </button>
                                            <ul class="dropdown-menu pull-left" role="menu">
                                                <li>
                                                    <a href="<?php echo e(route('admin.matricula.edit',$item->id)); ?>">
                                                        <i class="fa fa-edit"></i> Edit </a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo e(route('admin.matricula.delete',$item->id)); ?>">
                                                        <i class="fa fa-trash"></i> Delete </a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo e(route('admin.matricula.compromiso',$item->id)); ?>">
                                                        <i class="fa fa-file-pdf-o"></i> Compromiso </a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo e(route('admin.checklist.show',$item->id)); ?>">
                                                        <i class="fa fa-check"></i> CheckList </a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo e(route('admin.hermanos.show',$item->id)); ?>">
                                                        <i class="fa fa-users"></i> Hermanos </a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo e(route('admin.retiro.show',$item->id)); ?>">
                                                        <i class="fa fa-sign-out"></i> Retiro </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>
                        </table>
                    </div><!--/span-->
                </div><!--/row-->

            </div><!--/Porlet Body-->
        </div>
        <!-- END Portlet PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js-scripts'); ?>
<script>
$(document).ready(function() {

    $("#matriculables").select2({

        ajax: {
            url: '<?php echo e(url("/alumnos-matriculables")); ?>',
            dataType: 'json',
            delay: 250,
            data: function(params) {
                return {
                    varsearch: params.term // search term
                };
            },
            processResults: function(data) {
                // parse the results into the format expected by Select2.
                // since we are using custom formatting functions we do not need to
                // alter the remote JSON data
                return {
                    results: data
                };
            },
            cache: true
        },
        width: '100%',
        minimumInputLength: 3,
        templateResult: format,
        templateSelection: format,
        escapeMarkup: function(markup) {
            return markup;
        } // let our custom formatter work
    });
    function format(res){
        var markup=res.text;
        return markup;
    }
    $('#Matriculados').dataTable({
        "language": {
            "emptyTable": "No hay datos disponibles",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ filas",
            "search": "Buscar Alumnos :",
            "lengthMenu": "_MENU_ registros",
            "infoFiltered": " - filtrado para _MAX_ registros"
        },
        "bProcessing": true,
        "pagingType": "bootstrap_full_number",
        "order": [1,"asc"],
        "initComplete": function() {
            // Nivel column
            this.api().column(1).every(function(){
                var column = this;
                var select = $('<select class="form-control input-sm"><option value="">Nivel</option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );

                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            });
            // Grado
            this.api().column(2).every(function(){
                var column = this;
                var select = $('<select class="form-control input-sm"><option value="">Grado</option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );

                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            });
        }
    });

});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-styles'); ?>
<?php echo Html::style(asset('assets/global/plugins/bootstrap-table/bootstrap-table.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/select2/css/select2.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/select2/css/select2-bootstrap.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/datatables/datatables.min.css')); ?>

<?php echo Html::style('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-js'); ?>
<?php echo Html::script('assets/global/plugins/jquery-ui/jquery-ui.min.js'); ?>

<?php echo Html::script('assets/global/plugins/bootstrap-table/bootstrap-table.min.js'); ?>

<?php echo Html::script(asset('assets/global/plugins/select2/js/select2.full.min.js')); ?>

<?php echo Html::script(asset('assets/global/plugins/select2/js/i18n/es.js')); ?>

<?php echo Html::script('assets/global/scripts/datatable.js'); ?>

<?php echo Html::script('assets/global/plugins/datatables/datatables.min.js'); ?>

<?php echo Html::script('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Modulo de matricula
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>