<?php $__env->startSection('content'); ?>
<?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
    <div class="col-md-12">
        <?php echo Alert::render(); ?>

        <!-- BEGIN Portlet PORTLET-->
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-table"></i>
                    Listado de matriculas realizadas
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                    <a href="" class="fullscreen"> </a>
                    <a href="javascript:;" class="remove"> </a>
                </div>
            </div>
            <div class="portlet-body">
            <?php echo Form::model($matricula,['route'=>['admin.matricula.update',$matricula],'method'=>'PUT']); ?>

                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?php echo Form::label('lblAlumno', 'Matricula de: '.NombreAlumno($matricula->idalumno), ['class'=>'control-label']); ?>

                            <?php echo Form::hidden('idalumno', null); ?>

                        </div>
                    </div><!--/span-->
                </div><!--/row-->
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <?php echo Form::label('lblGrado', 'Escoger el grado al que fue promovido', ['class'=>'control-label']); ?>

                            <?php echo Form::select('idgradoseccion', $gradoseccion, null , ['class'=>'form-control']); ?>

                        </div>
                    </div><!--/span-->
                    <div class="col-md-4">
                        <div class="form-group">
                            <?php echo Form::label('lblTipo', 'Tipo de Matricula', ['class'=>'control-label']); ?>

                            <?php echo Form::select('idtipo', $tipomatricula, null , ['class'=>'form-control']); ?>

                        </div>
                    </div><!--/span-->
                    <div class="col-md-4">
                        <div class="form-group">
                            <?php echo Form::label('lblFecha', 'Año',['class'=>'control-label']);; ?>

                            <?php echo Form::text('year', null , ['class'=>'form-control']);; ?>

                        </div>
                    </div><!--/span-->
                </div><!--/row-->
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <p></p>
                        <?php echo Form::enviar('Actualizar'); ?>

                        <?php echo Form::back(route('admin.matricula.index')); ?>

                        </div>
                    </div><!--/span-->
                </div><!--/row-->
            <?php echo Form::close(); ?>

            </div><!--/Porlet Body-->
        </div>
        <!-- END Portlet PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Modulo de matricula
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>