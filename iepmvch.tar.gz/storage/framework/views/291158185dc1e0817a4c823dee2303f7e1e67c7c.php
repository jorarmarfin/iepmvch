<?php $__env->startSection('content'); ?>
<?php echo Alert::render(); ?>

<div class="portlet box red">
	<div class="portlet-title">
		<div class="caption"><i class="fa fa-gift"></i>Formulario de Usuarios </div>
	</div>
	<div class="portlet-body form">
		<?php echo Form::model($user,['route'=>['admin.users.destroy',$user],'method'=>'DELETE','files'=>true,'class'=>'form-horizontal']); ?>

			<div class="form-body">
				<div class="form-group">
					<?php echo Form::label('lblNombre', 'Nombre del usuario');; ?>

					<?php echo Form::text('name', null , ['class'=>'form-control','placeholder'=>'Nombre del usuario']);; ?>

				</div>
				<div class="form-group">
					<?php echo Form::label('lblEmail', 'Email');; ?>

					<?php echo Form::email('email', null , ['class'=>'form-control','placeholder'=>'Email']);; ?>

				</div>
				<div class="form-group">
					<?php echo Form::label('lblRol', 'Rol');; ?>

					<?php echo Form::select('idrole',$roles,null, ['class'=>'form-control']);; ?>

				</div>
				<div class="form-group">
					<div class="col-sm-4">
						<img src="<?php echo e(asset('/storage/'.Auth::user()->foto)); ?>" width="30%">
						<?php echo Form::file('file',['class'=>'form-control']); ?>

					</div>
				</div>


			</div>
			<div class="form-actions">
				<?php echo Form::submit('Eliminar',['class'=>'btn red uppercase']); ?>

				<a href="<?php echo e(route('admin.users.index')); ?>" class="btn default">REGRESAR</a>
			</div>
		<?php echo Form::close(); ?>

	</div>
</div>
<?php echo $__env->make('admin.users.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>