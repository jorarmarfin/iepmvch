<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
<?php echo Alert::render(); ?>

        <!-- BEGIN Portlet PORTLET-->
            <div class="portlet box green">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-user-md"></i>
                        Reserva Psicologica
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"> </a>
                        <a href="" class="fullscreen"> </a>
                        <a href="javascript:;" class="remove"> </a>
                    </div>
                </div>
                <div class="portlet-body">
                <?php echo Form::boton('Nueva Reserva',route('admin.reservapsicologica.create'),'green','fa fa-plus'); ?>

                <p></p>
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th> Persona Solicita</th>
                                <th> Grado </th>
                                <th> Motivo </th>
                                <th> Observacion </th>
                                <th> Estado </th>
                                <th> fecha </th>
                                <th> Personal que atendera </th>
                                <th> Opciones </th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $Lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr >
                                <td> <?php echo e($item->persona); ?> </td>
                                <td> <?php echo e($item->grado->nombre); ?> </td>
                                <td> <?php echo e($item->motivo); ?> </td>
                                <td> <?php echo e($item->observacion); ?> </td>
                                <td> <?php echo e($item->Estado->nombre); ?> </td>
                                <td> <?php echo e($item->fecha); ?> </td>
                                <td> <?php echo e($item->personal.' ('.$item->TipoPersonal.')'); ?> </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-xs green-dark dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"> Opciones
                                            <i class="fa fa-angle-down"></i>
                                        </button>
                                        <ul class="dropdown-menu pull-left" role="menu">
                                            <li>
                                                <a href="<?php echo e(route('admin.reservapsicologica.create',$item->id)); ?>">
                                                    <i class="icon-docs"></i> New </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('admin.reservapsicologica.edit',$item->id)); ?>">
                                                    <i class="fa fa-edit"></i> Edit </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('admin.reservapsicologica.show',$item->id)); ?>">
                                                    <i class="fa fa-trash"></i> Delete </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        <!-- END Portlet PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-styles'); ?>
<?php echo Html::style('assets/global/plugins/bootstrap-table/bootstrap-table.min.css'); ?>

<?php echo Html::style('assets/global/plugins/datatables/datatables.min.css'); ?>

<?php echo Html::style('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-js'); ?>
<?php echo Html::script('assets/global/plugins/jquery-ui/jquery-ui.min.js'); ?>

<?php echo Html::script('assets/global/plugins/bootstrap-table/bootstrap-table.min.js'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Modulo de matricula
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>