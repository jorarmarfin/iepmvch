<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
			<?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- BEGIN Portlet PORTLET-->
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-gift"></i> Nuevo Familiar </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                    <a href="javascript:;" class="fullscreen"> </a>
                    <a href="javascript:;" class="remove"> </a>
                </div>
            </div>
            <div class="portlet-body form">
                <!-- BEGIN FORM-->
				<?php echo Form::open(['route'=>'admin.familiar.store','method'=>'POST','class'=>'horizontal-form','files'=>true]); ?>

                    <div class="form-actions right">
                        <?php echo Form::enviar('Guardar'); ?>

                        <?php echo Form::back(route('admin.familiar.lists',$idalumno)); ?>

                    </div>
                    <div class="form-body">
                        <h3 class="form-section">Datos Personales</h3>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblViveEs', 'Vive con el Estudiante',['class'=>'control-label col-md-6']);; ?>

                                    <div class="input-group col-md-6">
                                        <div class="icheck-inline">
                                            <label>
                                                <?php echo Form::radio('viveconestudiante', 1); ?>

                                                Si
                                            </label>
                                            <label>
                                                <?php echo Form::radio('viveconestudiante', 0); ?>

                                                No
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblPaterno', 'Apellido paterno', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('paterno', null, ['class'=>'form-control','placeholder'=>'Apelido paterno']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
									<?php echo Form::label('lblMaterno', 'Apellido materno', ['class'=>'control-label']); ?>

									<?php echo Form::text('materno', null, ['class'=>'form-control','placeholder'=>'Apellido materno']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
									<?php echo Form::label('lblNombres', 'Nombres completos', ['class'=>'control-label']); ?>

									<?php echo Form::text('nombres', null, ['class'=>'form-control','placeholder'=>'Nombres completos']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblDNI', 'Numero de DNI', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('dni', null, ['class'=>'form-control','placeholder'=>'Numero de DNI']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblFecha', 'Fecha de nacimiento', ['class'=>'control-label']); ?>

                                    <?php echo Form::date('fechanacimiento', null , ['class'=>'form-control','placeholder'=>'Fecha de nacimiento']);; ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblPais', 'Pais de nacimiento',['class'=>'control-label']);; ?>

                                    <?php echo Form::select('idpais',$pais, IdPeru() , ['class'=>'form-control']);; ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblUbigeo', 'Lugar de nacimiento', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idubigeonacimiento',[], null , ['class'=>'form-control','id'=>'idubigeonacimiento']);; ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblReligion', 'Religion que profesa', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('religion', null , ['class'=>'form-control','placeholder'=>'Religion que profesa']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblSexo', 'Sexo', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idsexo', $sexo, IdMasculino() , ['class'=>'form-control']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblEstCivil', 'Estado Civil', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idestadocivil', $estadocivil, EstadoCivilId('ESTADO CIVIL','Casado') , ['class'=>'form-control']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblGradoIn', 'Grado de instruccion', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('gradoinstruccion', null, ['class'=>'form-control','placeholder'=>'Grado de instruccion']); ?>

                                </div>

                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblProfesion', 'Profesion', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('profesion', null, ['class'=>'form-control','placeholder'=>'Profesion']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblTipo', 'Tipo de familiar', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idtipo', $tipofamiliar, null , ['class'=>'form-control']); ?>

                                </div>

                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo Form::label('lblDireccion', 'Domicilio - calle', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('direccion', null, ['class'=>'form-control','placeholder'=>'Direccion completa']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblUbigeo', 'Dsitrito de residencia:', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idubigeo',[], null , ['class'=>'form-control','id'=>'idubigeo']);; ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblCelular', 'Telefono celular:', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('celular', null, ['class'=>'form-control','placeholder'=>'Celular']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblFijo', 'Telefono Fijo:', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('telefonofijo', null, ['class'=>'form-control','placeholder'=>'Telefono Fijo']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblLaboral', 'Telefono de Trabajo:', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('telefonolaboral', null, ['class'=>'form-control','placeholder'=>'Telefono de trabajo']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblEmail', 'Email', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('email', null, ['class'=>'form-control','placeholder'=>'Email']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblApoderado', '¿Es Apoderado?', ['class'=>'control-label']); ?>

                                    <div class="input-group col-md-6">
                                        <div class="icheck-inline">
                                            <label>
                                                <?php echo Form::radio('esapoderado', 1); ?>

                                                Si
                                            </label>
                                            <label>
                                                <?php echo Form::radio('esapoderado', 0); ?>

                                                No
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblAutorizo', 'Autorizo para incorporar y utilizar los siguientes datos', ['class'=>'control-label']); ?>

                                    <div class="input-group col-md-6">
                                        <div class="icheck-inline">
                                            <label>
                                                <?php echo Form::radio('autorizo', 1); ?>

                                                Si
                                            </label>
                                            <label>
                                                <?php echo Form::radio('autorizo', 0); ?>

                                                No
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--/span-->
                        </div><!--/row-->
                        <?php echo Form::hidden('idalumno', $idalumno); ?>

                    <div class="form-actions right">
                        <?php echo Form::enviar('Guardar'); ?>

                        <?php echo Form::back(route('admin.familiar.lists',$idalumno)); ?>

                    </div>
				<?php echo Form::close(); ?>

                <!-- END FORM-->
            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-scripts'); ?>
<script>
$(document).ready(function() {

    $("#idubigeonacimiento").select2({

        ajax: {
            url: '<?php echo e(url("/ubigeo")); ?>',
            dataType: 'json',
            delay: 250,
            data: function(params) {
                return {
                    varsearch: params.term // search term
                };
            },
            processResults: function(data) {
                // parse the results into the format expected by Select2.
                // since we are using custom formatting functions we do not need to
                // alter the remote JSON data
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        templateResult: format,
        templateSelection: format,
        escapeMarkup: function(markup) {
            return markup;
        } // let our custom formatter work
    });
    function format(res){
        var markup=res.text;
        return markup;
    }
    $("#idubigeo").select2({

        ajax: {
            url: '<?php echo e(url("/ubigeo")); ?>',
            dataType: 'json',
            delay: 250,
            data: function(params) {
                return {
                    varsearch: params.term // search term
                };
            },
            processResults: function(data) {
                // parse the results into the format expected by Select2.
                // since we are using custom formatting functions we do not need to
                // alter the remote JSON data
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        templateResult: format,
        templateSelection: format,
        escapeMarkup: function(markup) {
            return markup;
        } // let our custom formatter work
    });
    function format(res){
        var markup=res.text;
        return markup;
    }
    $('input').iCheck({
        checkboxClass: 'icheckbox_minimal',
        radioClass: 'iradio_minimal',
        increaseArea: '20%' // optional
    });
});
</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('plugins-styles'); ?>
<?php echo Html::style(asset('assets/global/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/select2/css/select2.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/select2/css/select2-bootstrap.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/icheck/skins/all.css')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins-js'); ?>
<?php echo Html::script(asset('assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js')); ?>

<?php echo Html::script(asset('assets/global/plugins/select2/js/select2.full.min.js')); ?>

<?php echo Html::script(asset('assets/global/plugins/select2/js/i18n/es.js')); ?>

<?php echo Html::script(asset('assets/global/plugins/icheck/icheck.min.js')); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Creando familiar para <?php echo e(NombreAlumno($idalumno)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>