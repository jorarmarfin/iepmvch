<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
    <?php echo Alert::render(); ?>

        <!-- BEGIN Portlet PORTLET-->
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-table"></i>
                    Lista de boletas de venta
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                    <a href="" class="fullscreen"> </a>
                    <a href="javascript:;" class="remove"> </a>
                </div>
            </div>
            <div class="portlet-body">
            <?php echo Form::boton('Nueva Boleta',route('admin.boletaventa.create'),'green','fa fa-plus'); ?>

            <p></p>
                <table class="table table-striped table-hover" id="Asignaturas">
                    <thead>
                        <tr>
                            <th> Serie </th>
                            <th> Numero </th>
                            <th> Fecha Emision</th>
                            <th> Razion social</th>
                            <th> Total Venta</th>
                            <th> Opciones </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $Lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td> <?php echo e(pad($item->serie,3,0,'L')); ?> </td>
                            <td> <?php echo e(pad($item->numero,8,'0','L')); ?> </td>
                            <td> <?php echo e($item->fechaemision); ?> </td>
                            <td> <?php echo e($item->razonsocial); ?> </td>
                            <td> <?php echo e($item->total_venta); ?> </td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-xs green-dark dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"> Opciones
                                        <i class="fa fa-angle-down"></i>
                                    </button>
                                    <ul class="dropdown-menu pull-left" role="menu">
                                        <li>
                                            <a href="<?php echo e(route('admin.boletaventa.show',$item->id)); ?>">
                                                <i class="fa fa-file-pdf-o"></i> Show </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(asset('/storage/boletaventa/'.$item->archivo_cabecera)); ?>">
                                                <i class="fa fa-file"></i> Cabecera </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(asset('/storage/boletaventa/'.$item->archivo_detalle)); ?>">
                                                <i class="fa fa-file"></i> Detalle </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin.asignatura.show',$item->id)); ?>">
                                                <i class="fa fa-trash"></i> Delete </a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-scripts'); ?>
<script>
$('#Asignaturas').dataTable({
    "language": {
        "emptyTable": "No hay datos disponibles",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ filas",
        "search": "Buscar :",
        "lengthMenu": "_MENU_ registros"
    },
    "bProcessing": true,
    "pagingType": "bootstrap_full_number",
    "order": [1,"asc"]
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-styles'); ?>
<?php echo Html::style('assets/global/plugins/datatables/datatables.min.css'); ?>

<?php echo Html::style('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-js'); ?>
<?php echo Html::script('assets/global/plugins/jquery-ui/jquery-ui.min.js'); ?>

<?php echo Html::script('assets/global/scripts/datatable.js'); ?>

<?php echo Html::script('assets/global/plugins/datatables/datatables.min.js'); ?>

<?php echo Html::script('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Boleta de venta
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>