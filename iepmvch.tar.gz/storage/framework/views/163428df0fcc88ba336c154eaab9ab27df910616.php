<?php echo Form::open(['route'=> 'admin.users.store','method'=> 'POST','files'=>true,'class'=>'']); ?>

<div class="modal fade" id="myModalNewUser" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h4 class="modal-title">Nuevo Usuario</h4>
            </div>
            <div class="modal-body">
              <div class="form-horizontal">
                <div class="form-group">
                    <?php echo Form::label('lblNombres','Nombres',['class'=>'col-sm-2 control-label']); ?>

                    <div class="col-sm-10 ">
                      <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Nombres']); ?>

                    </div>
                </div>
                <div class="form-group">
                  <?php echo Form::label('lblemail','Email',['class'=>'col-sm-2 control-label']); ?>

                  <div class="col-sm-10 ">
                    <?php echo Form::text('email',null,['class'=>'form-control','placeholder'=>'Email']); ?>

                  </div>
                </div>
                <div class="form-group">
                  <?php echo Form::label('lblPassword','Password',['class'=>'col-sm-2 control-label']); ?>

                  <div class="col-sm-10 ">
                    <?php echo Form::password('password',['class'=>'form-control']); ?>

                  </div>
                </div>
                <div class="form-group">
                  <?php echo Form::label('lblRol','Rol',['class'=>'col-sm-2 control-label']); ?>

                  <div class="col-sm-10 ">
                    <?php echo Form::select('idrole', $roles,null,['class'=>'form-control','id'=>'idrole']);; ?>

                  </div>
                </div>
                <div class="form-group">
                    <?php echo Form::label('lblFoto','Foto',['class'=>'col-sm-2 control-label']); ?>

                  <div class="col-sm-10">
                  <?php echo Form::file('file',['class'=>'form-control']); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
                <?php echo Form::button('Cerrar',['class'=>'btn btn-default pull-left','data-dismiss'=>'modal']); ?>

                <?php echo Form::submit('Guardar',['class'=>'btn btn-primary']); ?>

            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<?php echo Form::close(); ?>