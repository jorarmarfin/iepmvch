<?php $__env->startSection('content'); ?>
<?php echo Alert::render(); ?>

<div class="row">
	<div class="col-md-8">
		<div class="portlet box green">
			<div class="portlet-title">
				<div class="caption">
					<i class="fa fa-table"></i>
					Usuarios
				</div>
			</div>
			<div class="portlet-body">
				<a href="#myModalNewUser" data-toggle="modal" class="btn blue">
					<i class="fa fa-plus"></i>
					<i class="fa fa-user"></i>
				</a>
				<div class="table-scrollable">
					<table class="table table-striped table-hover" data-toggle="table" data-pagination="true" data-search="true">
						<thead>
							<tr>
								<th>Nombre</th>
								<th>fecha</th>
								<th>foto</th>
								<th>Opciones</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $Lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<tr>
								<td><?php echo e($item->name); ?></td>
								<td><?php echo e($item->email); ?></td>
								<td><img src="<?php echo e(asset('/storage/'.$item->foto)); ?>" width='25px'></td>
								<td>
									<a href="<?php echo e(route('admin.users.edit',$item->id)); ?>" title="Editar"class="btn btn-icon-only green-haze" >
										<i class="fa fa-edit"></i>
									</a>
									<a href="<?php echo e(route('admin.users.show',$item->id)); ?>" title="Eliminar" class="btn -btn-icon-only red">
										<i class="fa fa-trash"></i>
									</a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
						</tbody>
					</table>

				</div>
			</div>

		</div>
	</div>
</div>
<?php echo $__env->make('admin.users.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('plugins-styles'); ?>
<?php echo Html::style('assets/global/plugins/bootstrap-table/bootstrap-table.min.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-plugins'); ?>
<?php echo Html::script('assets/global/plugins/jquery-ui/jquery-ui.min.js'); ?>

<?php echo Html::script('assets/global/plugins/bootstrap-table/bootstrap-table.min.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>