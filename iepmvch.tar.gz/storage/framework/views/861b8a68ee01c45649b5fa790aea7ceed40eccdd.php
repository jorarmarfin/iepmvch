<?php $__env->startSection('content'); ?>
<?php echo Form::open(['url'=>'/password/email','method'=>'POST','class'=>'forget-form']); ?>

    <?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <h3 class="font-green">¿ Olvidaste tu contraseña ?</h3>
    <p> Ingresa tu correo electronico y te enviaremos un email para poder acceder. </p>
    <div class="form-group">
        <?php echo Form::email('email',old('email'), ['class'=>'form-control form-control-solid placeholder-no-fix form-group','placeholder'=>'Email']); ?>

    </div>
    <div class="form-actions">
       <a href="<?php echo e(url('/')); ?>" class="btn green btn-outline">REGRESAR</a>
       <?php echo Form::submit('Enviar',['class'=>'btn btn-success uppercase pull-right']); ?>

    </div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-scripts'); ?>
<script>
 $('.login-bg').backstretch([
    "<?php echo e(url('assets/pages/img/login/bg1.jpg')); ?>",
    "<?php echo e(url('assets/pages/img/login/bg2.jpg')); ?>",
    "<?php echo e(url('assets/pages/img/login/bg3.jpg')); ?>",
    "<?php echo e(url('assets/pages/img/login/bg4.jpg')); ?>",
    "<?php echo e(url('assets/pages/img/login/bg6.jpg')); ?>",
    "<?php echo e(url('assets/pages/img/login/bg7.jpg')); ?>"
    ], {
      fade: 1000,
      duration: 1000
    }
);
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mensaje'); ?>
Bienvenido al sistema de acceso del colegio donde podra acceder a diversos servicios que brindamos on line
<?php $__env->stopSection(); ?>

<?php $__env->startSection('copyright'); ?>
SAHOST - 2014 © Metronic. Admin Dashboard Template.
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>