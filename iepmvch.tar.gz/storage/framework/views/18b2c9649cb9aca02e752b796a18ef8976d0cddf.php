<li>
    <a href="page_user_profile_1.html">
        <i class="icon-user"></i> Mi Perfil
    </a>
</li>
<li>
	<a href="<?php echo e(url('/logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
  		<i class="icon-key"></i> Salir
  	</a>
  	<form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
        <?php echo e(csrf_field()); ?>

    </form>
</li>