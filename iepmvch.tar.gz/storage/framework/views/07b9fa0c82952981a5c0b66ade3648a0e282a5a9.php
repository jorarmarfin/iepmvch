<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
			<?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- BEGIN Portlet PORTLET-->
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-plus"></i>Crear Reserva Psicologica </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse" data-original-title="" title=""> </a>
                    <a href="javascript:;" class="fullscreen"> </a>
                    <a href="javascript:;" class="remove" data-original-title="" title=""> </a>
                </div>
            </div>
            <div class="portlet-body form">
                <!-- BEGIN FORM-->
				<?php echo Form::open(['route'=>'admin.reservapsicologica.store','method'=>'POST','class'=>'form-horizontal']); ?>

                    <div class="form-body">
						<div class="form-group">
							<?php echo Form::label('lblPersona', 'Persona para atender',['class'=>'col-md-3 control-label']);; ?>

							<div class="col-md-9">
							<?php echo Form::text('persona', null , ['class'=>'form-control','placeholder'=>'Persona']);; ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('lblGrado', 'Grado que desea matricular',['class'=>'col-md-3 control-label']);; ?>

							<div class="col-md-9">
							<?php echo Form::select('idgrado',$grado, null , ['class'=>'form-control']);; ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('lblMotivo', 'Motivo de consulta',['class'=>'col-md-3 control-label']);; ?>

							<div class="col-md-9">
							<?php echo Form::text('motivo', null , ['class'=>'form-control','placeholder'=>'Motivo de la consulta']);; ?>

							</div>
						</div>

						<div class="form-group">
							<?php echo Form::label('lblObservacion', 'Observacion',['class'=>'col-md-3 control-label']);; ?>

							<div class="col-md-9">
							<?php echo Form::textarea('observacion', null , ['class'=>'form-control','placeholder'=>'Observacion']);; ?>

							</div>
						</div>
						<div class="form-group">
							<?php echo Form::label('lblFecha', 'Fecha',['class'=>'col-md-3 control-label']);; ?>

							<div class="col-md-9">
								<div class="input-group date form_datetime">
								<?php echo Form::text('fecha', null , ['class'=>'form-control','placeholder'=>'fecha y hora']);; ?>

	                                <span class="input-group-btn">
	                                    <button class="btn default date-set" type="button">
	                                        <i class="fa fa-calendar"></i>
	                                    </button>
	                                </span>
	                            </div>
							</div>

						</div>
						<div class="form-group">
							<?php echo Form::label('lblPesonal', 'Pesonal que atendera',['class'=>'col-md-3 control-label']);; ?>

							<div class="col-md-9">
							<?php echo Form::select('idpersonal',$personalData, null , ['class'=>'form-control','placeholder'=>'Seleccionar personal que atendera']);; ?>

							</div>
						</div>

                    </div>
                    <div class="form-actions">
                        <div class="row">
                            <div class="col-md-offset-3 col-md-9">
								<?php echo Form::enviar('Guardar'); ?>

								<?php echo Form::back(route('admin.reservapsicologica.index')); ?>

                            </div>
                        </div>
                    </div>
				<?php echo Form::close(); ?>

                <!-- END FORM-->
				<div class="row">
                	<div class="col-md-12">

                	<p><h3>Horario disponible de psicologos</h3></p>
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th> Personal </th>
                                <th> Dia </th>
                                <th> Inicio </th>
                                <th> fin </th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $hp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td> <?php echo e($item->personal); ?> </td>
                            <td> <?php echo e($item->dia); ?> </td>
                            <td> <?php echo e($item->inicio); ?> </td>
                            <td> <?php echo e($item->fin); ?> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                	</div><!--span-->
                </div><!--row-->
            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-scripts'); ?>
<script>
$(".form_datetime").datetimepicker({
	todayBtn: true,
    autoclose: true,
    isRTL: App.isRTL(),
    format: "yyyy-mm-dd hh:ii",
    pickerPosition: (App.isRTL() ? "bottom-right" : "bottom-left")
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-styles'); ?>
<?php echo Html::style(asset('assets/global/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins-js'); ?>
<?php echo Html::script(asset('assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js')); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Modulo de matricula
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>