<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
			<?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- BEGIN Portlet PORTLET-->
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-gift"></i> Editar Alumno </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                    <a href="javascript:;" class="fullscreen"> </a>
                    <a href="javascript:;" class="remove"> </a>
                </div>
            </div>
            <div class="portlet-body form">
                <!-- BEGIN FORM-->
				<?php echo Form::model($alumno,['route'=>['admin.alumnos.update',$alumno],'method'=>'PUT','class'=>'horizontal-form','files'=>true]); ?>

                    <div class="portlet-body form">
                        <div class="form-actions right">
                            <?php echo Form::enviar('Guardar'); ?>

                            <?php echo Form::back(route('admin.alumnos.index')); ?>



                        </div>
                    <div class="form-body">
                        <h3 class="form-section">Datos Personales</h3>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
									<?php echo Form::label('paterno', 'Apellido Paterno', ['class'=>'control-label']); ?>

									<?php echo Form::text('paterno', null, ['class'=>'form-control','placeholder'=>'Apellido Paterno']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
									<?php echo Form::label('lblMaterno', 'Apellido Materno', ['class'=>'control-label']); ?>

									<?php echo Form::text('materno', null, ['class'=>'form-control','placeholder'=>'Apellido Materno']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
									<?php echo Form::label('lblNombres', 'Nombres', ['class'=>'control-label']); ?>

									<?php echo Form::text('nombres', null, ['class'=>'form-control','placeholder'=>'Nombres completos']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
									<?php echo Form::label('lblDNI', 'Numero de DNI', ['class'=>'control-label']); ?>

									<?php echo Form::text('dni', null, ['class'=>'form-control','placeholder'=>'Numero de DNI']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                <?php echo Form::label('lblGrado', 'Grado Actual del alumno',['class'=>'control-label']);; ?>

                                    <?php echo Form::select('idgrado',$grado, null , ['class'=>'form-control']);; ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblFecha', 'Fecha de nacimiento', ['class'=>'control-label']); ?>

                                    <?php echo Form::date('fechanacimiento', null , ['class'=>'form-control','placeholder'=>'Fecha de nacimiento']);; ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblPais', 'Pais de nacimiento',['class'=>'control-label']);; ?>

                                    <?php echo Form::select('idpais',$pais, null , ['class'=>'form-control']);; ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblUbigeo', 'Lugar de nacimiento', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idubigeonacimiento',UbigeoPersonal('ubigeo',$alumno->idubigeonacimiento), null , ['class'=>'form-control','id'=>'idubigeonacimiento']);; ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblReligion', 'Religion que profesa', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('religion', null , ['class'=>'form-control','placeholder'=>'Religion que profesa']); ?>

                                </div>
                                <div class="form-group">
                                    <?php echo Form::label('lblSexo', 'Sexo', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idsexo', $sexo, null , ['class'=>'form-control']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblSacramentos', 'Sacramentos',['class'=>'control-label']);; ?>

                                    <div class="input-group">
                                        <div class="icheck-list">
                                            <label>
                                                <?php echo Form::checkbox('bautismo',true); ?>

                                                 Bautizo
                                            </label>
                                            <label>
                                                <?php echo Form::checkbox('comunion',true); ?>

                                                Comunión
                                            </label>
                                            <label>
                                                <?php echo Form::checkbox('confirmacion',true); ?>

                                                Confirmación
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo Form::label('lblDireccion', 'Domicilio - calle', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('direccion', null, ['class'=>'form-control','placeholder'=>'Nombres completos']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblUbigeo', 'Distrito de residencia', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idubigeo',UbigeoPersonal('ubigeo',$alumno->idubigeo), null , ['class'=>'form-control','id'=>'idubigeo']);; ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblTelefonos', 'Telefonos', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('telefonos', null, ['class'=>'form-control','placeholder'=>'Telefonos']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblTelefonoE1', 'Telefono de emergencia 1 / Preguntar por:', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('telefonoemergencia1', null, ['class'=>'form-control','placeholder'=>'Telefono de emergencia']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblTelefonoE2', 'Telefono de emergencia 2 / Preguntar por:', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('telefonoemergencia2', null, ['class'=>'form-control','placeholder'=>'Telefono de emergencia']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblResEco', 'Responsable economico', ['class'=>'control-label']); ?>

                                    <div class="input-group">
                                        <div class="icheck-inline">
                                            <label>
                                                <?php echo Form::radio('responsableeconomico', 'padre',true); ?>

                                                Padre
                                            </label>
                                            <label>
                                                <?php echo Form::radio('responsableeconomico', 'madre'); ?>

                                                Madre
                                            </label>
                                            <label>
                                                <?php echo Form::radio('responsableeconomico', 'apoderado'); ?>

                                                Apoderado
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblColegio', 'Colegio de procedencia', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('colegioprocedencia', null, ['class'=>'form-control','placeholder'=>'Colegio de procedencia']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <h3 class="form-section">Fotografia</h3>
                        <div class="row">
                            <div class="col-md-12">
                                <img src="<?php echo e(asset('/storage/'.$alumno->foto)); ?>" width='10%'>
                                <div class="form-group">
                                    <?php echo Form::file('file', []); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <h3 class="form-section">Observacion</h3>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo Form::label('lblEsEspecial', 'Es un niño especial',['class'=>'control-label col-md-2']);; ?>

                                    <div class="input-group col-md-10">
                                        <div class="icheck-inline">
                                            <label>
                                                <?php echo Form::radio('esespecial', 1); ?>

                                                Si
                                            </label>
                                            <label>
                                                <?php echo Form::radio('esespecial', 0); ?>

                                                No
                                            </label>
                                        </div>
                                    </div>
                                    <?php echo Form::textarea('discapacidad', null, ['class'=>'form-control']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo Form::label('lblObservacion', 'Observacion, deudas, etc',['class'=>'control-label']);; ?>

                                    <?php echo Form::textarea('observacion', null, ['class'=>'form-control']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <?php echo Form::hidden('idestado', EstadoId('ESTADO ALUMNO','Regular')); ?>

                        </div>
                    <div class="form-actions right">
                        <?php echo Form::enviar('Guardar'); ?>

                        <?php echo Form::back(route('admin.alumnos.index')); ?>

                    </div>
				<?php echo Form::close(); ?>

                <!-- END FORM-->
            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-scripts'); ?>
<script>
$(document).ready(function() {

    $("#idubigeonacimiento").select2({

        ajax: {
            url: '<?php echo e(url("/ubigeo")); ?>',
            dataType: 'json',
            delay: 250,
            data: function(params) {
                return {
                    varsearch: params.term // search term
                };
            },
            processResults: function(data) {
                // parse the results into the format expected by Select2.
                // since we are using custom formatting functions we do not need to
                // alter the remote JSON data
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        templateResult: format,
        templateSelection: format,
        escapeMarkup: function(markup) {
            return markup;
        } // let our custom formatter work
    });
    function format(res){
        var markup=res.text;
        return markup;
    }
    $("#idubigeo").select2({

        ajax: {
            url: '<?php echo e(url("/ubigeo")); ?>',
            dataType: 'json',
            delay: 250,
            data: function(params) {
                return {
                    varsearch: params.term // search term
                };
            },
            processResults: function(data) {
                // parse the results into the format expected by Select2.
                // since we are using custom formatting functions we do not need to
                // alter the remote JSON data
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        templateResult: format,
        templateSelection: format,
        escapeMarkup: function(markup) {
            return markup;
        } // let our custom formatter work
    });
    function format(res){
        var markup=res.text;
        return markup;
    }
    $('input').iCheck({
        checkboxClass: 'icheckbox_minimal',
        radioClass: 'iradio_minimal',
        increaseArea: '20%' // optional
    });
});
</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('plugins-styles'); ?>
<?php echo Html::style(asset('assets/global/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/select2/css/select2.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/select2/css/select2-bootstrap.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/icheck/skins/all.css')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins-js'); ?>
<?php echo Html::script(asset('assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js')); ?>

<?php echo Html::script(asset('assets/global/plugins/select2/js/select2.full.min.js')); ?>

<?php echo Html::script(asset('assets/global/plugins/select2/js/i18n/es.js')); ?>

<?php echo Html::script(asset('assets/global/plugins/icheck/icheck.min.js')); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Datos de alumnos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>