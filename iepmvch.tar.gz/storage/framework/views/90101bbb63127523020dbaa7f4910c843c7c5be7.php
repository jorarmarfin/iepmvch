<div class="page-sidebar-wrapper">
<div class="page-sidebar navbar-collapse collapse">
    <ul class="page-sidebar-menu page-sidebar-menu-hover-submenu page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
        <!-- BEGIN SIDEBAR TOGGLER BUTTON -->
        <li class="sidebar-toggler-wrapper hide">
            <div class="sidebar-toggler">
                <span></span>
            </div>
        </li>
        <!-- END SIDEBAR TOGGLER BUTTON -->
        <?php echo Form::menu('Escritorio',route('home.index'),'icon-home','start'); ?>

        <li class="heading">
            <h3 class="uppercase">Sistema</h3>
        </li>
        <?php echo Form::menu('Usuarios',route('admin.users.index'),'icon-users'); ?>

        <li class="nav-item  ">
            <?php echo Form::menulink('Configuracion','#','fa fa-cogs'); ?>

            <ul class="sub-menu">
                <?php echo Form::menu('Maestro',route('catalogo.gestion','maestro')); ?>

                <?php echo Form::menu('Pais',route('catalogo.gestion','pais')); ?>

                <?php echo Form::menu('Tipo Familiar',route('catalogo.gestion','tipo familiar')); ?>

            </ul>
        </li>
        <li class="heading">
            <h3 class="uppercase">Modulos</h3>
        </li>
        <?php echo Form::menu('Matricula',route('admin.matricula.index'),'fa fa-cube'); ?>

        <?php echo Form::menu('Psicologia',route('admin.reservapsicologica.index'),'fa fa-user-md'); ?>

        <?php echo Form::menu('Alumnos',route('admin.alumnos.index'),'fa fa-users'); ?>

        <?php echo Form::menu('Personal',route('admin.personal.index'),'fa fa-graduation-cap'); ?>

        <li class="nav-item  ">
            <?php echo Form::menulink('Plan Curricular','#','fa fa-cubes'); ?>

            <ul class="sub-menu">
                <?php echo Form::menu('Areas academicas',route('admin.areaacademica.index')); ?>

                <?php echo Form::menu('Asignaturas',route('admin.asignatura.index')); ?>

                <?php echo Form::menu('Asignaturas Grado',route('admin.ags.index')); ?>

                <?php echo Form::menu('Horario',route('admin.asignatura.index')); ?>

            </ul>
        </li>
        <li class="nav-item  ">
            <?php echo Form::menulink('Caja','#','fa fa-money'); ?>

            <ul class="sub-menu">
                <?php echo Form::menu('Boleta Venta',route('admin.boletaventa.index')); ?>

                <?php echo Form::menu('Recibo',route('admin.boletaventa.index')); ?>

                <?php echo Form::menu('Productos',route('admin.productos.index')); ?>

                <?php echo Form::menu('Serie',route('admin.serie.index')); ?>

            </ul>
        </li>
        <?php echo Form::menu('Registros','#','icon-book-open'); ?>

        <?php echo Form::menu('Almacen','#','fa fa-archive'); ?>

        <?php echo Form::menu('Pensiones','#','fa fa-dollar'); ?>

        <?php echo Form::menu('Cumpleaños','#','icon-present'); ?>

        <?php echo Form::menu('Lista de Utiles',route('admin.listautiles.index'),'fa fa-list'); ?>

        <?php echo Form::menu('Memos','#','fa fa-thumbs-o-down'); ?>

        <?php echo Form::menu('Calendarizacion','#','fa fa-calendar'); ?>

        <?php echo Form::menu('Busqueda','#','fa fa-search'); ?>

        <?php echo Form::menu('Postulaciones','#','fa fa-user-plus'); ?>

        <?php echo Form::menu('Diplomas','#','icon-badge'); ?>


    </ul>
    <!-- END SIDEBAR MENU -->
    <!-- END SIDEBAR MENU -->
</div>
<!-- END SIDEBAR -->
</div>
