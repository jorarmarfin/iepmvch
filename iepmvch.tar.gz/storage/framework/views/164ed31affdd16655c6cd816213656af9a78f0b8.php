<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
			<?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- BEGIN Portlet PORTLET-->
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-gift"></i> Editar Personal </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                    <a href="javascript:;" class="fullscreen"> </a>
                    <a href="javascript:;" class="remove"> </a>
                </div>
            </div>
            <div class="portlet-body form">
                <!-- BEGIN FORM-->
				<?php echo Form::model($personal,['route'=>['admin.personal.update',$personal],'method'=>'PUT','class'=>'horizontal-form','files'=>true]); ?>

                    <div class="form-actions right">
                        <?php echo Form::enviar('Guardar'); ?>

                        <?php echo Form::back(route('admin.personal.index')); ?>

                    </div>
                    <div class="form-body">
                        <h3 class="form-section">Datos Personales</h3>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
									<?php echo Form::label('paterno', 'Apellido Paterno', ['class'=>'control-label']); ?>

									<?php echo Form::text('paterno', null, ['class'=>'form-control','placeholder'=>'Apellido Paterno']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
									<?php echo Form::label('lblMaterno', 'Apellido Materno', ['class'=>'control-label']); ?>

									<?php echo Form::text('materno', null, ['class'=>'form-control','placeholder'=>'Apellido Materno']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
									<?php echo Form::label('lblNombres', 'Nombres', ['class'=>'control-label']); ?>

									<?php echo Form::text('nombres', null, ['class'=>'form-control','placeholder'=>'Nombres completos']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
									<?php echo Form::label('lblDNI', 'Numero de DNI', ['class'=>'control-label']); ?>

									<?php echo Form::text('dni', null, ['class'=>'form-control','placeholder'=>'Numero de DNI']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblFecha', 'Fecha de nacimiento', ['class'=>'control-label']); ?>

                                    <?php echo Form::date('fechanacimiento', null , ['class'=>'form-control','placeholder'=>'Fecha de nacimiento']);; ?>

                                </div>
                            </div><!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblEmail', 'Email', ['class'=>'control-label']); ?>

                                    <?php echo Form::email('email', null, ['class'=>'form-control','placeholder'=>'Email del personal']); ?>

                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblEstCivil', 'Estado Civil', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idestadocivil', $estadocivil, EstadoCivilId('ESTADO CIVIL','Soltero') , ['class'=>'form-control']); ?>

                                </div>

                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblSexo', 'Sexo', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idsexo', $sexo, IdMasculino() , ['class'=>'form-control']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblPais', 'Pais de nacimiento',['class'=>'control-label']);; ?>

                                    <?php echo Form::select('idpais',$pais, IdPeru() , ['class'=>'form-control']);; ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblUbigeo', 'Distrito de nacimiento', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idubigeonacimiento',UbigeoPersonal('Lugar de nacimiento',$personal->idubigeonacimiento), null , ['class'=>'form-control','id'=>'idubigeonacimiento']);; ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo Form::label('lblDireccion', 'Domicilio - calle', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('direccion', null, ['class'=>'form-control','placeholder'=>'Direccion completa']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblUbigeo', 'Distrito de residencia', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idubigeo',UbigeoPersonal('Lugar de nacimiento',$personal->idubigeo), null , ['class'=>'form-control','id'=>'idubigeo']);; ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblHijos', 'Numero de Hijos', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('numerohijos', null, ['class'=>'form-control','placeholder'=>'Numero Hijos']); ?>

                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblTelefonoFijo', 'Telefono Fijo', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('telefonofijo', null, ['class'=>'form-control','placeholder'=>'Telefono Fijo','maxlength'=>'100']); ?>

                                </div>
                            </div><!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblCelular', 'Celular', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('celular', null, ['class'=>'form-control','placeholder'=>'Celular','maxlength'=>'100']); ?>

                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblUniversidad', 'Universidad', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('universidad', null, ['class'=>'form-control','placeholder'=>'Universidad','maxlength'=>'100']); ?>

                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblCulmino', 'Culmino', ['class'=>'control-label']); ?>

                                    <div class="input-group">
                                        <div class="icheck-inline">
                                            <label>
                                                <?php echo Form::radio('culmino', true,true); ?>

                                                Si
                                            </label>
                                            <label>
                                                <?php echo Form::radio('culmino', false); ?>

                                                No
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblCarrera', 'Carrera', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('carrera', null, ['class'=>'form-control','placeholder'=>'Carrera']); ?>

                                </div>
                            </div><!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblGestion', 'Gestion de la universidad', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idgestionuniversidad',$gestion, null , ['class'=>'form-control','placeholder'=>'Selecionar Gestion']);; ?>

                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblGrado', 'Grado Obtenido', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('gradoobtenido', null, ['class'=>'form-control','placeholder'=>'Grado Obtenido']); ?>

                                </div>
                            </div><!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblFecha', 'Fecha de egreso', ['class'=>'control-label']); ?>

                                    <?php echo Form::date('fechaegreso', null , ['class'=>'form-control','placeholder'=>'Fecha de egreso']);; ?>

                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblColegiatura', 'Numero de colegiatura', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('numerocolegiatura', null, ['class'=>'form-control','placeholder'=>'Numero de Colegiatura']); ?>

                                </div>
                            </div><!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblPension', 'Sistema de Pension', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idsistemapension',$sistemapension ,null, ['class'=>'form-control','placeholder'=>'Seleccionar Sistema de Pension']); ?>

                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblAfp', 'Ingresar AFP si corresponde', ['class'=>'control-label']); ?>

                                    <?php echo Form::text('afp', null, ['class'=>'form-control','placeholder'=>'nombre del afp']); ?>

                                </div>
                            </div><!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblVigente', 'Está Vigente', ['class'=>'control-label']); ?>

                                    <div class="input-group">
                                        <div class="icheck-inline">
                                            <label>
                                                <?php echo Form::radio('vigente', true,true); ?>

                                                Si
                                            </label>
                                            <label>
                                                <?php echo Form::radio('vigente', false); ?>

                                                No
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('lblTipo', 'Tipo de Personal', ['class'=>'control-label']); ?>

                                    <?php echo Form::select('idtipo',$tipopersonal, EstadoId('TIPO PERSONAL','Docente'), ['class'=>'form-control','placeholder'=>'Tipo de Personal']); ?>

                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <h3 class="form-section">Fotografia</h3>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo Form::file('file', []); ?>

                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <?php echo Form::hidden('idestado', EstadoId('ESTADO ALUMNO','Regular')); ?>

                    <div class="form-actions right">
                        <?php echo Form::enviar('Guardar'); ?>

                        <?php echo Form::back(route('admin.personal.index')); ?>

                    </div>
				<?php echo Form::close(); ?>

                <!-- END FORM-->
            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-scripts'); ?>
<script>
$(document).ready(function() {

    $("#idubigeonacimiento").select2({

        ajax: {
            url: '<?php echo e(url("/ubigeo")); ?>',
            dataType: 'json',
            delay: 250,
            data: function(params) {
                return {
                    varsearch: params.term // search term
                };
            },
            processResults: function(data) {
                // parse the results into the format expected by Select2.
                // since we are using custom formatting functions we do not need to
                // alter the remote JSON data
                return {
                    results: data
                };
            },
            cache: true
        },
        width:'auto',
        minimumInputLength: 3,
        templateResult: format,
        templateSelection: format,
        escapeMarkup: function(markup) {
            return markup;
        } // let our custom formatter work
    });
    function format(res){
        var markup=res.text;
        return markup;
    }
    $("#idubigeo").select2({

        ajax: {
            url: '<?php echo e(url("/ubigeo")); ?>',
            dataType: 'json',
            delay: 250,
            data: function(params) {
                return {
                    varsearch: params.term // search term
                };
            },
            processResults: function(data) {
                // parse the results into the format expected by Select2.
                // since we are using custom formatting functions we do not need to
                // alter the remote JSON data
                return {
                    results: data
                };
            },
            cache: true
        },
        width:'auto',
        minimumInputLength: 3,
        templateResult: format,
        templateSelection: format,
        escapeMarkup: function(markup) {
            return markup;
        } // let our custom formatter work
    });
    function format(res){
        var markup=res.text;
        return markup;
    }
    $('input').iCheck({
        checkboxClass: 'icheckbox_minimal',
        radioClass: 'iradio_minimal',
        increaseArea: '20%' // optional
    });
});
</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('plugins-styles'); ?>
<?php echo Html::style(asset('assets/global/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/select2/css/select2.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/select2/css/select2-bootstrap.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/icheck/skins/all.css')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins-js'); ?>
<?php echo Html::script(asset('assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js')); ?>

<?php echo Html::script(asset('assets/global/plugins/select2/js/select2.full.min.js')); ?>

<?php echo Html::script(asset('assets/global/plugins/select2/js/i18n/es.js')); ?>

<?php echo Html::script(asset('assets/global/plugins/icheck/icheck.min.js')); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Modulo de Personal
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>