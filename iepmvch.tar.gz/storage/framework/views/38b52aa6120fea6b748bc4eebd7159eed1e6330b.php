<?php $__env->startSection('content'); ?>
<div class="note note-danger">
    <h4 class="block">Cuidado! Esta seguro de eliminar esta boleta: <?php echo e('B'.pad($caja->serie,3,'0','L').'-'.pad($caja->numero,8,'0','L')); ?></h4>
    <p> No podra desacer esta opcion </p>
</div>
<div class="row">
    <div class="col-md-12">
    <?php echo Alert::render(); ?>

        <!-- BEGIN Portlet PORTLET-->
        <div class="portlet box red">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-table"></i>
                    BORRAR BOLETA
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                    <a href="" class="fullscreen"> </a>
                    <a href="javascript:;" class="remove"> </a>
                </div>
            </div>
            <div class="portlet-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="control-label col-md-6"> <strong> Fecha de Emision: </strong></label>
                            <label class="control-label col-md-6 text-left"> <?php echo e($caja->fechaemision); ?></label>
                        </div>
                    </div> <!--/span-->
                    <div class="col-md-5">
                        <div class="form-group">
                            <label class="control-label col-md-6"> <strong> Documento de identidad: </strong></label>
                            <label class="control-label col-md-6 text-left"> <?php echo e($caja->numidentificacion); ?></label>
                        </div>
                    </div> <!--/span-->
                </div> 
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-4"> <strong> Razon Social: </strong></label>
                            <p class="control-label col-md-8 text-left"> <?php echo e($caja->razonsocial); ?></p>
                        </div>
                    </div> <!--/span-->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-4"> <strong> Direccion: </strong></label>
                            <p class="control-label col-md-8 text-left"> <?php echo e($caja->direccion); ?></p>
                        </div>
                    </div> <!--/span-->
                </div> 
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-4"> <strong> Alumno: </strong></label>
                            <p class="control-label col-md-8 text-left"> <?php echo e($caja->matricula->alumno->nombre_completo); ?></p>
                        </div>
                    </div> <!--/span-->
                </div> 
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-4"> <strong> Total venta: </strong></label>
                            <p class="control-label col-md-8 text-left"> <?php echo e($caja->total_venta); ?></p>
                        </div>
                    </div> <!--/span-->
                </div> 
            <p></p>
                <table class="table table-striped table-hover" id="Boletas">
                    <thead>
                        <tr>
                            <th> Cantidad </th>
                            <th> Producto </th>
                            <th> Precio Unitario</th>
                            <th> Descuento</th>
                            <th> Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $caja->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td> <?php echo e($item->cantidad); ?> </td>
                            <td> <?php echo e($item->producto->nombre.' '.$item->tipo_pension); ?> </td>
                            <td> <?php echo e($item->preciounitario); ?> </td>
                            <td> <?php echo e($item->descuento); ?> </td>
                            <td> <?php echo e($item->total); ?> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </tbody>
                </table>
            <?php echo Form::model($caja,['route'=>['admin.boletaventa.destroy',$caja],'method'=>'DELETE']); ?>

                <?php echo Form::enviar('Eliminar','red','fa-trash'); ?>

                <?php echo Form::back(route('admin.boletaventa.index')); ?>

            <?php echo Form::close(); ?>

            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
</div>
<div class="modal fade" id="Numeracion" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h4 class="modal-title">Actualizar Numeracion</h4>
            </div>

            <?php echo Form::open(['route'=>'admin.boletaventa.storenumeracion','method'=>'POST']); ?>

            <div class="modal-body">
                <?php echo Form::label('lblNumeracion', 'Colocar el numero de serie al que desea actualizar ', ['class'=>'control-label']); ?>

                <?php echo Form::text('numero', null, ['class'=>'form-control']); ?>


            </div>
            <div class="modal-footer">
                <?php echo Form::enviar('Actualizarr'); ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-scripts'); ?>
<script>

$('#Boletas').dataTable({
    "language": {
        "emptyTable": "No hay datos disponibles",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ filas",
        "search": "Buscar :",
        "lengthMenu": "_MENU_ registros"
    },
    "bProcessing": true,
    "pagingType": "bootstrap_full_number",
    "order": [1,"asc"]
});

</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-styles'); ?>
<?php echo Html::style('assets/global/plugins/datatables/datatables.min.css'); ?>

<?php echo Html::style('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-js'); ?>
<?php echo Html::script('assets/global/plugins/jquery-ui/jquery-ui.min.js'); ?>

<?php echo Html::script('assets/global/scripts/datatable.js'); ?>

<?php echo Html::script('assets/global/plugins/datatables/datatables.min.js'); ?>

<?php echo Html::script('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Boleta de venta
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>