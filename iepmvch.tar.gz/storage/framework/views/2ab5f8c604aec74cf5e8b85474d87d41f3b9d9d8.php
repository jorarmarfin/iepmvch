<?php $__env->startSection('content'); ?>
<div class="portlet box green">
	<div class="portlet-title">
		<div class="caption"><i class="fa fa-edit"></i>Formulario de Usuarios </div>
	</div>
	<div class="portlet-body form">
		<?php echo Form::model($catalogo,['route'=>['catalogo.update',$catalogo],'method'=>'PUT']); ?>

			<div class="form-body">
				<?php if(Session::get('tablename') != 'jefatura'): ?>
					<div class="form-group">
						<?php echo Form::label('lblCodigo', 'Codigo');; ?>

						<?php echo Form::text('codigo', null , ['class'=>'form-control','placeholder'=>'Codigo']);; ?>

					</div>
				<?php endif; ?>
				<div class="form-group">
					<?php echo Form::label('lblNombre', 'Nombre del cargo');; ?>

					<?php echo Form::text('nombre', null , ['class'=>'form-control','placeholder'=>'Nombre del cargo']);; ?>

				</div>
				<div class="form-group">
					<?php echo Form::label('lblDescripcion', 'Descripcion');; ?>

					<?php echo Form::text('descripcion', null , ['class'=>'form-control','placeholder'=>'Descripcion']);; ?>

				</div>

            	<div class="form-group">
					<?php echo Form::submit('Guardar',['class'=>'btn yellow-gold uppercase']); ?>

	            	<a href="<?php echo e(route('catalogo.index')); ?>" class="btn default">REGRESAR</a>
            	</div>
            </div>
		<?php echo Form::close(); ?>

	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Credencial:CNE
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
Editar <?php echo e(Session::get('tablename')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user-menu'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-img'); ?>
<?php echo asset('storage/fotos/'.Auth::user()->foto); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>