<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title><?php echo $__env->yieldContent('title','Institucion Educativa Milagrosa Virgen de Chapi'); ?></title>
    <!-- BEGIN PAGE FIRST SCRIPTS -->
    <?php echo $__env->yieldContent('js-plugins-first'); ?>
    <!-- END PAGE FIRST SCRIPTS -->
    <!-- BEGIN PAGE TOP STYLES -->
    <?php echo $__env->yieldContent('styles-plugins-first'); ?>
    <!-- END PAGE TOP STYLES -->
	<?php echo $__env->make('layouts.partials.styles-mandatory', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('layouts.partials.styles-plugins', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('layouts.partials.styles-global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('layouts.partials.styles-theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.partials.template-favicon', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
	<div class="page-wrapper">
        <!-- BEGIN HEADER -->
        <?php echo $__env->make('layouts.partials.template-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- END HEADER -->
        <!-- BEGIN HEADER & CONTENT DIVIDER -->
        <div class="clearfix"> </div>
        <!-- END HEADER & CONTENT DIVIDER -->
        <!-- BEGIN CONTAINER -->
        <div class="page-container">
            <!-- BEGIN SIDEBAR -->
            <?php echo $__env->make('layouts.partials.template-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- END SIDEBAR -->
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                    <!-- BEGIN THEME PANEL -->
                    <!-- END THEME PANEL -->
                    <!-- BEGIN PAGE BAR -->
                    <?php echo $__env->make('layouts.partials.template-breadcumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h1 class="page-title"> <?php echo $__env->yieldContent('page-title','Blank Page Layout'); ?>
                        <small><?php echo $__env->yieldContent('page-subtitle','blank page layout'); ?></small>
                    </h1>
                    <!-- END PAGE TITLE-->
                    <!-- END PAGE HEADER-->
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
            <!-- BEGIN QUICK SIDEBAR -->
            <!-- END QUICK SIDEBAR -->
        </div>
        <!-- END CONTAINER -->
        <!-- BEGIN FOOTER -->
        <?php echo $__env->make('layouts.partials.template-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- END FOOTER -->
    </div>
	<!-- BEGIN CORE PLUGINS -->
	<?php echo $__env->make('layouts.partials.js-core', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('plugins-js'); ?>
    <!-- END CORE PLUGINS -->
    <!-- BEGIN THEME GLOBAL SCRIPTS -->
    <script src=<?php echo e(asset("assets/global/scripts/app.min.js")); ?> type="text/javascript"></script>
    <!-- END THEME GLOBAL SCRIPTS -->
    <!-- BEGIN THEME LAYOUT SCRIPTS -->
    <script src=<?php echo e(asset("assets/layouts/layout/scripts/layout.min.js")); ?> type="text/javascript"></script>
    <script src=<?php echo e(asset("assets/layouts/layout/scripts/demo.min.js")); ?> type="text/javascript"></script>
    <script src=<?php echo e(asset("assets/layouts/global/scripts/quick-sidebar.min.js")); ?> type="text/javascript"></script>
    <!-- END THEME LAYOUT SCRIPTS -->
    <?php echo $__env->yieldContent('js-scripts'); ?>
</body>
