<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
    <?php echo Alert::render(); ?>

    <?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- BEGIN Portlet PORTLET-->
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-table"></i>
                    Familiares
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                    <a href="" class="fullscreen"> </a>
                    <a href="javascript:;" class="remove"> </a>
                </div>
            </div>
            <div class="portlet-body">
                <?php echo Form::open(['route'=>'admin.familiar.relation','method'=>'POST']); ?>

                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <?php echo Form::label('lblAlumno', 'Si el padre ya existe puede escogerlo y asignarlo al alumno', ['class'=>'control-label']); ?>

                            <?php echo Form::select('idfamiliar', [], null , ['class'=>'form-control','id'=>'familiares']); ?>

                            <?php echo Form::hidden('idalumno', $id); ?>

                        </div>
                    </div><!--/span-->
                    <div class="col-md-4">
                        <div class="form-group">
                            <p></p>
                        <?php echo Form::enviar('Agregar'); ?>

                        </div>
                    </div><!--/span-->
                </div><!--/row-->
                <?php echo Form::close(); ?>

                <?php echo Form::boton('Nuevo Familiar',route('admin.familiar.create',$id),'green','fa fa-plus'); ?>

                <?php echo Form::back(route('admin.alumnos.index')); ?>

            <p></p>
                <table class="table table-hover table-bordered" >
                    <thead>
                        <tr>
                            <th> Paterno </th>
                            <th> Materno </th>
                            <th> Nombres </th>
                            <th> Opciones </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $Lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td> <?php echo e($item->paterno); ?> </td>
                            <td> <?php echo e($item->materno); ?> </td>
                            <td> <?php echo e($item->nombres.' ('.$item->tipo.')'); ?> </td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-xs green-dark dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"> Opciones
                                        <i class="fa fa-angle-down"></i>
                                    </button>
                                    <ul class="dropdown-menu pull-left" role="menu">
                                        <li>
                                            <a href="<?php echo e(route('admin.familiar.show',$item->id)); ?>">
                                                <i class="fa fa-eye"></i> Show </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin.familiar.edit',$item->id)); ?>">
                                                <i class="fa fa-edit"></i> Edit </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin.familiar.delete',$item->id)); ?>">
                                                <i class="fa fa-trash"></i> Delete </a>
                                        </li><li>
                                            <a href="<?php echo e(route('admin.familiar.quitar',$item->id)); ?>">
                                                <i class="fa fa-mail-reply"></i> Quitar </a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js-scripts'); ?>
<script>
$(document).ready(function() {

    $("#familiares").select2({

        ajax: {
            url: '<?php echo e(url("/familiares")); ?>',
            dataType: 'json',
            delay: 250,
            data: function(params) {
                return {
                    varsearch: params.term // search term
                };
            },
            processResults: function(data) {
                // parse the results into the format expected by Select2.
                // since we are using custom formatting functions we do not need to
                // alter the remote JSON data
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        templateResult: format,
        templateSelection: format,
        escapeMarkup: function(markup) {
            return markup;
        } // let our custom formatter work
    });
    function format(res){
        var markup=res.text;
        return markup;
    }

});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-styles'); ?>
<?php echo Html::style('assets/global/plugins/bootstrap-table/bootstrap-table.min.css'); ?>

<?php echo Html::style(asset('assets/global/plugins/select2/css/select2.min.css')); ?>

<?php echo Html::style(asset('assets/global/plugins/select2/css/select2-bootstrap.min.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-js'); ?>
<?php echo Html::script('assets/global/plugins/jquery-ui/jquery-ui.min.js'); ?>

<?php echo Html::script('assets/global/plugins/bootstrap-table/bootstrap-table.min.js'); ?>

<?php echo Html::script(asset('assets/global/plugins/select2/js/select2.full.min.js')); ?>

<?php echo Html::script(asset('assets/global/plugins/select2/js/i18n/es.js')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Familiar de alumno <?php echo e(NombreAlumno($id)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>