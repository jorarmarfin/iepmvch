<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
			<?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- BEGIN Portlet PORTLET-->
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-user"></i>Detalle de Personal </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                    <a href="#portlet-config" data-toggle="modal" class="config"> </a>
                    <a href="javascript:;" class="reload"> </a>
                    <a href="javascript:;" class="remove"> </a>
                </div>
            </div>
            <div class="portlet-body form">
                    <div class="form-actions right">
                    <?php echo Form::back(route('admin.personal.index')); ?>

                    </div>
                <!-- BEGIN FORM-->
                <form class="form-horizontal" role="form">
                    <div class="form-body">
                        <h2 class="margin-bottom-20"> Ficha de <?php echo e($personal->tipo); ?>: <?php echo e($personal->nombre_completo); ?> </h2>
                        <h3 class="form-section">Informacion Personal</h3>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="thumbnail">
                                    <img src="<?php echo e(asset('/storage/'.$personal->foto)); ?>" width="300px">
                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-6">Apellido Paterno:</label>
                                            <div class="col-md-6">
                                                <p class="form-control-static"> <?php echo e($personal->paterno); ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-6">Apellido Materno:</label>
                                            <div class="col-md-6">
                                                <p class="form-control-static"> <?php echo e($personal->materno); ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                </div>
                                <!--/row-->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-6">Nombres:</label>
                                            <div class="col-md-6">
                                                <p class="form-control-static"> <?php echo e($personal->nombres); ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-6">Cumpleaños:</label>
                                            <div class="col-md-6">
                                                <p class="form-control-static"> <?php echo e($personal->fechanacimiento); ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                </div>
                                <!--/row-->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-6">Sexo:</label>
                                            <div class="col-md-6">
                                                <p class="form-control-static"> <?php echo e($personal->sexo); ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-6">DNI:</label>
                                            <div class="col-md-6">
                                                <p class="form-control-static"> <?php echo e($personal->dni); ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                </div>
                                <!--/row-->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-6">Edad:</label>
                                            <div class="col-md-6">
                                                <p class="form-control-static"> <?php echo e($personal->edad); ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-6">Pais nacimiento:</label>
                                            <div class="col-md-6">
                                                <p class="form-control-static"> <?php echo e($personal->pais.' / '.$personal->ubigeo_nacimiento); ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                </div>
                                <!--/row-->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-6">Email:</label>
                                            <div class="col-md-6">
                                                <p class="form-control-static"> <?php echo e($personal->email); ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-6">Estado Civil:</label>
                                            <div class="col-md-6">
                                                <p class="form-control-static"> <?php echo e($personal->estado_civil); ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                </div>
                                <!--/row-->
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <h3 class="form-section">Dirección</h3>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-3">Direccion:</label>
                                    <div class="col-md-9">
                                        <p class="form-control-static"> <?php echo e($personal->direccion); ?> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-3">Localidad:</label>
                                    <div class="col-md-9">
                                        <p class="form-control-static"> <?php echo e($personal->ubigeo); ?> </p>
                                    </div>
                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-3">numero hijos:</label>
                                    <div class="col-md-9">
                                        <p class="form-control-static"> <?php echo e($personal->numerohijos); ?> </p>
                                    </div>
                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="control-label col-md-3">Telefono fijo:</label>
                                    <div class="col-md-9">
                                        <p class="form-control-static"> <?php echo e($personal->telefonofijo); ?> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--/row-->
                        <div class="row">
                            <!--/span-->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="control-label col-md-3">Celular:</label>
                                    <div class="col-md-9">
                                        <p class="form-control-static"> <?php echo e($personal->celular); ?> </p>
                                    </div>
                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <h3 class="form-section">Datos academicos</h3>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-6">Universidad:</label>
                                    <div class="col-md-6">
                                        <p class="form-control-static"> <?php echo e($personal->universidad); ?> </p>
                                    </div>
                                </div>
                            </div><!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-6">Culmino:</label>
                                    <div class="col-md-6">
                                        <p class="form-control-static"> <?php echo e($personal->culmino_carrera); ?> </p>
                                    </div>
                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-6">Carrera:</label>
                                    <p class="form-control-static "> <?php echo $personal->carrera; ?> </p>
                                </div>
                            </div><!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-6">Gestion universidad:</label>
                                    <p class="form-control-static "> <?php echo $personal->gestion_universidad; ?> </p>
                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-6">Grado Obtenido:</label>
                                    <p class="form-control-static "> <?php echo $personal->gradoobtenido; ?> </p>
                                </div>
                            </div><!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-6">Grado Obte:</label>
                                    <p class="form-control-static "> <?php echo $personal->carrera; ?> </p>
                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-6">Fecha egreso:</label>
                                    <p class="form-control-static "> <?php echo $personal->fechaegreso; ?> </p>
                                </div>
                            </div><!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-6">Numero de Colegiatura:</label>
                                    <p class="form-control-static "> <?php echo $personal->numerocolegiatura; ?> </p>
                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                         <h3 class="form-section">Datos de Pension</h3>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-6">Sistema de Pension:</label>
                                    <div class="col-md-6">
                                        <p class="form-control-static"> <?php echo e($personal->sistema_pension); ?> </p>
                                    </div>
                                </div>
                            </div><!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-6">AFP:</label>
                                    <div class="col-md-6">
                                        <p class="form-control-static"> <?php echo e($personal->afp); ?> </p>
                                    </div>
                                </div>
                            </div><!--/span-->
                        </div><!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-6">Es vigente:</label>
                                    <div class="col-md-6">
                                        <p class="form-control-static"> <?php echo e($personal->es_vigente); ?> </p>
                                    </div>
                                </div>
                            </div><!--/span-->

                        </div><!--/row-->
                    </div>
                    <div class="form-actions right">
                    <?php echo Form::back(route('admin.personal.index')); ?>

                    </div>
                </form>
                <!-- END FORM-->
            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('menu-user'); ?>
<?php echo $__env->make('menu.profile-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make(Auth::user()->menu, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('user-name'); ?>
<?php echo Auth::user()->name; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title'); ?>
Datos de Alumno
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-subtitle'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>