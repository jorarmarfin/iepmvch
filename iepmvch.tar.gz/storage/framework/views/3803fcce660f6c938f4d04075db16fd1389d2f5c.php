<?php $__env->startSection('content'); ?>
<?php echo Form::open(['url'=>'login','method'=>'POST','class'=>'login-form']); ?>

    <?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
            <div class="col-xs-6">
            <?php echo Form::email('email',old('email'), ['class'=>'form-control form-control-solid placeholder-no-fix form-group','placeholder'=>'Email']); ?>

            </div>
        <div class="col-xs-6">
            <?php echo Form::password('password', ['class'=>'form-control form-control-solid placeholder-no-fix form-group','placeholder'=>'Clave']); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="rem-password">
            </div>
        </div>
        <div class="col-sm-8 text-right">
            <div class="forgot-password">
                <a href="<?php echo e(url('/password/reset')); ?>" class="forget-password">Olvide mi clave</a>
            </div>
            <?php echo Form::submit('Entrar',['class'=>'btn green uppercase']); ?>

        </div>
    </div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-scripts'); ?>
<script>
 $('.login-bg').backstretch([
    "<?php echo e(url('assets/pages/img/login/bg1.jpg')); ?>",
    "<?php echo e(url('assets/pages/img/login/bg2.jpg')); ?>",
    "<?php echo e(url('assets/pages/img/login/bg3.jpg')); ?>",
    "<?php echo e(url('assets/pages/img/login/bg4.jpg')); ?>",
    "<?php echo e(url('assets/pages/img/login/bg6.jpg')); ?>",
    "<?php echo e(url('assets/pages/img/login/bg7.jpg')); ?>"
    ], {
      fade: 1000,
      duration: 1000
    }
);
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mensaje'); ?>
Bienvenido al sistema de acceso del colegio donde podra acceder a diversos servicios que brindamos on line
<?php $__env->stopSection(); ?>

<?php $__env->startSection('copyright'); ?>
SAHOST - 2014 © Metronic. Admin Dashboard Template.
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>