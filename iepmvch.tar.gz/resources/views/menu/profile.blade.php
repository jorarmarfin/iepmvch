<li>
    <a href="page_user_profile_1.html">
        <i class="icon-user"></i> Mi Perfil
    </a>
</li>
<li>
	<a href="{{route('auth.logout')}}">
  		<i class="icon-key"></i> Salir
  	</a>
</li>