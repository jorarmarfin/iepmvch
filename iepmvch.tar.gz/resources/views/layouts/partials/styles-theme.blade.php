<!-- BEGIN THEME LAYOUT STYLES -->
<link href={{asset("assets/layouts/layout/css/layout.css")}} rel="stylesheet" type="text/css" />
<link href={{asset("assets/layouts/layout/css/themes/grey.min.css")}} rel="stylesheet" type="text/css" id="style_color" />
<link href={{asset("assets/layouts/layout/css/custom.min.css")}} rel="stylesheet" type="text/css" />
<!-- END THEME LAYOUT STYLES -->
