<?php

return [
	'failed'=>  'Estas credenciales no coinciden con nuestros registros.',
];